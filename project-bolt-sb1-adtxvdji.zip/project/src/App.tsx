import React, { useEffect, useRef, useState } from 'react';
import { Bone as Drone, ChevronDown, Shield, Award, Zap, Phone, Plus, Minus, Play, Star } from 'lucide-react';

function App() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const whatsappNumber = "+5563999573578";
  const whatsappMessage = "Olá! Gostaria de saber mais sobre os drones DJI.";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scroll = window.scrollY;
        heroRef.current.style.transform = `translateZ(${scroll * 0.1}px)`;
        heroRef.current.style.opacity = `${1 - scroll * 0.002}`;
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const faqItems = [
    {
      question: 'Qual é o prazo de entrega dos produtos?',
      answer: 'O prazo de entrega varia de acordo com a região, mas geralmente é entre 3 a 7 dias úteis para capitais e 7 a 14 dias úteis para outras localidades.'
    },
    {
      question: 'Os drones possuem garantia?',
      answer: 'Sim, todos os nossos produtos possuem garantia oficial DJI de 1 ano contra defeitos de fabricação.'
    },
    {
      question: 'Vocês oferecem suporte técnico?',
      answer: 'Sim, contamos com uma equipe especializada para suporte técnico, tanto durante quanto após o período de garantia.'
    },
    {
      question: 'Quais formas de pagamento são aceitas?',
      answer: 'Aceitamos cartões de crédito, boleto bancário, PIX e parcelamento em até 12x sem juros.'
    },
    {
      question: 'Preciso de licença para pilotar os drones?',
      answer: 'Dependendo do modelo e finalidade de uso, sim. Nossa equipe pode orientar sobre as regulamentações e documentações necessárias.'
    }
  ];

  const videos = [
    {
      id: 'DkZRls3f3Js',
      title: 'DJI Mini 4 Pro - Voo Noturno',
      description: 'Imagens incríveis capturadas com o DJI Mini 4 Pro durante a noite'
    },
    {
      id: 'nXBJ8GR4khs',
      title: 'DJI Mini 4 Pro - Voo em Cachoeira',
      description: 'Explorando paisagens naturais com o DJI Mini 4 Pro'
    },
    {
      id: 'vNJEWtmSyCI',
      title: 'DJI Mini 4 Pro - Voo em Cidade',
      description: 'Capturando a beleza urbana com o DJI Mini 4 Pro'
    }
  ];

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="relative h-screen overflow-hidden perspective-1000">
        <div
          ref={heroRef}
          className="absolute inset-0 flex items-center justify-center"
          style={{ transform: 'translateZ(0)' }}
        >
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1473968512647-3e447244af8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center opacity-40" />
          <div className="relative z-10 text-center px-4">
            <div className="flex items-center justify-center mb-6">
              <Drone className="w-16 h-16 text-blue-500 animate-float" />
              <h1 className="text-6xl font-bold ml-4">Cia DJI Oficial</h1>
            </div>
            <p className="text-2xl mb-8 text-blue-300">Distribuidor Oficial DJI</p>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full text-xl font-bold transition-all hover:scale-105"
            >
              Explorar Produtos
            </a>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-10 h-10 text-blue-500" />
        </div>
      </div>

      {/* About Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1506947411487-a56738267384?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-fixed opacity-10" />
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <h2 className="text-4xl font-bold mb-6">Sobre a Cia DJI Oficial</h2>
              <p className="text-gray-300 text-lg leading-relaxed">
                Somos uma empresa especializada na comercialização de drones DJI, comprometida em trazer as mais avançadas tecnologias de voo para nossos clientes.
              </p>
              <p className="text-gray-300 text-lg leading-relaxed">
                Como distribuidor oficial DJI no Brasil, garantimos produtos originais, suporte especializado e a melhor experiência em compra de drones.
              </p>
              <div className="grid grid-cols-2 gap-6 mt-8">
                <div className="border border-blue-500 rounded-lg p-4 text-center">
                  <h3 className="text-3xl font-bold text-blue-500 mb-2">5+</h3>
                  <p className="text-gray-400">Anos de Experiência</p>
                </div>
                <div className="border border-blue-500 rounded-lg p-4 text-center">
                  <h3 className="text-3xl font-bold text-blue-500 mb-2">1000+</h3>
                  <p className="text-gray-400">Clientes Satisfeitos</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1524143986875-3b098d78b363?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Drone em voo"
                className="rounded-lg shadow-2xl transform hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-lg">
                <p className="text-xl font-bold">Distribuidor</p>
                <p className="text-sm">Oficial DJI</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 px-4">
        <h2 className="text-4xl font-bold text-center mb-16">Produtos em Destaque</h2>
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              name: 'DJI Mini 3 Pro',
              image: 'https://images.unsplash.com/photo-1579829366248-204fe8413f31?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
              description: 'Câmera 4K, 34 min de voo, menos de 249g',
            },
            {
              name: 'DJI Air 2S',
              image: 'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
              description: 'Sensor 1", 5.4K vídeo, autonomia de 31 min',
            },
            {
              name: 'DJI Mavic 3',
              image: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
              description: 'Hasselblad 4/3 CMOS, 46 min de voo',
            },
          ].map((product, index) => (
            <div
              key={index}
              className="bg-gray-900 rounded-xl overflow-hidden transform hover:scale-105 transition-all duration-300"
            >
              <img src={product.image} alt={product.name} className="w-full h-64 object-cover" />
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">{product.name}</h3>
                <p className="text-gray-400 mb-4">{product.description}</p>
                <a
                  href={`${whatsappUrl}&text=Olá! Gostaria de saber mais sobre o ${product.name}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full bg-blue-600 hover:bg-blue-700 py-3 rounded-lg text-center"
                >
                  Saiba Mais
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-6">O Que Dizem Nossos Clientes</h2>
          <p className="text-gray-400 text-center mb-16 max-w-2xl mx-auto">
            Confira a experiência de quem já escolheu a Cia DJI Oficial para realizar seus projetos
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Pedro Silva',
                role: 'Fotógrafo Profissional',
                image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
                testimonial: 'Excelente atendimento e suporte técnico. O drone chegou perfeitamente e tem superado todas as expectativas nos meus trabalhos.',
              },
              {
                name: 'Ana Costa',
                role: 'Videomaker',
                image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
                testimonial: 'A qualidade dos produtos e o conhecimento da equipe são impressionantes. Recomendo fortemente para qualquer profissional da área.',
              },
              {
                name: 'Lucas Mendes',
                role: 'Cinegrafista',
                image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
                testimonial: 'Encontrei na Cia DJI Oficial o parceiro ideal para meus projetos. Produtos originais e garantia de procedência são fundamentais.',
              },
            ].map((testimonial, index) => (
              <div key={index} className="bg-gray-800 rounded-xl p-6 transform hover:scale-105 transition-all duration-300">
                <div className="flex items-center mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-bold text-lg">{testimonial.name}</h3>
                    <p className="text-blue-400">{testimonial.role}</p>
                  </div>
                </div>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 italic">{testimonial.testimonial}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Por que escolher a Cia DJI Oficial?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: Shield,
                title: 'Garantia Oficial',
                description: 'Produtos com garantia oficial DJI Brasil',
              },
              {
                icon: Award,
                title: 'Distribuidor Autorizado',
                description: 'Parceiro oficial DJI com suporte especializado',
              },
              {
                icon: Zap,
                title: 'Entrega Rápida',
                description: 'Envio expresso para todo o Brasil',
              },
            ].map((feature, index) => (
              <div key={index} className="text-center">
                <feature.icon className="w-16 h-16 text-blue-500 mx-auto mb-6" />
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* YouTube Videos Section */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-6">Conteúdo em Destaque</h2>
          <p className="text-gray-400 text-center mb-16 max-w-2xl mx-auto">
            Confira nossos vídeos com reviews, tutoriais e dicas para aproveitar ao máximo seu drone
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {videos.map((video, index) => (
              <div key={index} className="bg-gray-900 rounded-xl overflow-hidden">
                <div className="aspect-video">
                  <iframe
                    width="100%"
                    height="100%"
                    src={`https://www.youtube.com/embed/${video.id}?rel=0&autoplay=0`}
                    title={video.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{video.title}</h3>
                  <p className="text-gray-400">{video.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Perguntas Frequentes</h2>
          <div className="space-y-4">
            {faqItems.map((item, index) => (
              <div key={index} className="border border-gray-800 rounded-lg overflow-hidden">
                <button
                  className="w-full px-6 py-4 flex items-center justify-between text-left bg-gray-900 hover:bg-gray-800 transition-colors"
                  onClick={() => toggleFaq(index)}
                >
                  <span className="text-lg font-semibold">{item.question}</span>
                  {openFaq === index ? (
                    <Minus className="w-5 h-5 text-blue-500" />
                  ) : (
                    <Plus className="w-5 h-5 text-blue-500" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="px-6 py-4 bg-gray-800 text-gray-300">
                    {item.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-8">Entre em Contato</h2>
          <p className="text-xl text-gray-400 mb-12">
            Tire suas dúvidas com nossa equipe especializada
          </p>
          <div className="flex items-center justify-center space-x-6">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-full transition-all hover:scale-105"
            >
              <Phone className="w-6 h-6 mr-2" />
              Fale Conosco
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-6">
            <Drone className="w-8 h-8 text-blue-500" />
            <span className="text-2xl font-bold ml-2">Cia DJI Oficial</span>
          </div>
          <p className="text-gray-400">
            © {new Date().getFullYear()} Cia DJI Oficial. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;